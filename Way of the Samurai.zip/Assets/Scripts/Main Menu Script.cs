﻿using UnityEngine;
using System.Collections;

public class MainMenuScript : MonoBehaviour {

	public Texture backgroundTexture;
}
